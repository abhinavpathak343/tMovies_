import Hero from "./Hero";

export {Hero};